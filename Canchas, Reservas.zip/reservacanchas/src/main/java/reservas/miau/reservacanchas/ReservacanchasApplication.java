package reservas.miau.reservacanchas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservacanchasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservacanchasApplication.class, args);
	}

}

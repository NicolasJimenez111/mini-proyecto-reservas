package reservas.miau.reservacanchas.services;

import java.util.List;

import reservas.miau.reservacanchas.entities.Cancha;

public interface CanchaServices {

    Cancha crearCancha(Cancha cancha);
    Cancha obtenerIdCancha(Long id);
    List<Cancha> listaCanchas();

}

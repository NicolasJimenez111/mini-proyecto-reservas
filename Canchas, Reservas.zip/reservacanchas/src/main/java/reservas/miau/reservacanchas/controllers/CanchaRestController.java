package reservas.miau.reservacanchas.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reservas.miau.reservacanchas.entities.Cancha;
import reservas.miau.reservacanchas.services.CanchaServices;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
@RequestMapping("/canchas")
public class CanchaRestController {

    @Autowired
    private CanchaServices canchaServices;

    @PostMapping
    public ResponseEntity<Cancha> crearCancha(@RequestBody Cancha cancha) {
        Cancha nuevCancha = canchaServices.crearCancha(cancha);
        return ResponseEntity.ok(nuevCancha);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cancha> obtenerIdCancha(@PathVariable Long id) {
        Cancha cancha = canchaServices.obtenerIdCancha(id);
        return ResponseEntity.ok(cancha);
    }
    
    @GetMapping
    public ResponseEntity<List<Cancha>> listarCanchas() {
        List<Cancha> canchas = canchaServices.listaCanchas();
        return ResponseEntity.ok(canchas);
    }

}

package reservas.miau.reservacanchas.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import reservas.miau.reservacanchas.entities.Cancha;
import reservas.miau.reservacanchas.repository.CanchaRepositories;

@Service
public class CanchaServicesImpl implements CanchaServices {

    @Autowired
    private CanchaRepositories canchaRepositories;

    @Override
    public Cancha crearCancha(Cancha cancha) {
        return canchaRepositories.save(cancha);
    }

    @Override
    public Cancha obtenerIdCancha(Long id) {
        return canchaRepositories.findById(id).orElse(null);
    }

    @Override
    public List<Cancha> listaCanchas() {
        return (List<Cancha>) canchaRepositories.findAll();
    }

}

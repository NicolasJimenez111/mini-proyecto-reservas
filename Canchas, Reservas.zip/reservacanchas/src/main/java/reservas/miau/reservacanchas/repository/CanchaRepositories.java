package reservas.miau.reservacanchas.repository;

import org.springframework.data.repository.CrudRepository;

import reservas.miau.reservacanchas.entities.Cancha;

public interface CanchaRepositories extends CrudRepository<Cancha, Long>{

}

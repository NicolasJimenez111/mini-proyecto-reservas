package reservas.miau.reservacanchas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservacanchasApplicationTests {

	@Test
	void contextLoads() {
	}

}

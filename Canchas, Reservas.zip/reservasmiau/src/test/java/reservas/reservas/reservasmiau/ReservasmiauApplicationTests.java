package reservas.reservas.reservasmiau;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservasmiauApplicationTests {

	@Test
	void contextLoads() {
	}

}

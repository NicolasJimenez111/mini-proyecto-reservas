package reservas.reservas.reservasmiau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservasmiauApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservasmiauApplication.class, args);
	}

}

package reservas.reservas.reservasmiau.services;

import reservas.reservas.reservasmiau.entities.Reserva;

import java.util.List;

public interface ReservaServices {

    Reserva crearReserva(Reserva reserva);
    Reserva obtenerIdReserva(Long id);
    List<Reserva> listaReservas();
    List<Reserva> listaReservasPorCancha(Long idCancha);
}

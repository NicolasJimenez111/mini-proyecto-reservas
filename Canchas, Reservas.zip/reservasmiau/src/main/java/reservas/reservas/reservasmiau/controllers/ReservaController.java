package reservas.reservas.reservasmiau.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reservas.reservas.reservasmiau.entities.Reserva;
import reservas.reservas.reservasmiau.services.ReservaServices;

@RestController
@RequestMapping("/reservas")
public class ReservaController {

    @Autowired
    private ReservaServices reservaServices;

    @PostMapping
    public ResponseEntity<?> crearReserva(@RequestBody Reserva reserva) {
        Reserva nuevaReserva = reservaServices.crearReserva(reserva);
        if (nuevaReserva == null) {
            return ResponseEntity.badRequest().body("La cancha no existe");
        }
        return ResponseEntity.ok(nuevaReserva);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reserva> obtenerIdReserva(@PathVariable Long id) {
        Reserva reserva = reservaServices.obtenerIdReserva(id);
        return ResponseEntity.ok(reserva);
    }

    @GetMapping
    public ResponseEntity<List<Reserva>> listaReservas() {
        List<Reserva> reservas = reservaServices.listaReservas();
        return ResponseEntity.ok(reservas);
    }

    @GetMapping("/cancha/{idCancha}")
    public ResponseEntity<List<Reserva>> listaReservasPorCancha(@PathVariable Long idCancha) {
        List<Reserva> reservas = reservaServices.listaReservasPorCancha(idCancha);
        return ResponseEntity.ok(reservas);
    }
}

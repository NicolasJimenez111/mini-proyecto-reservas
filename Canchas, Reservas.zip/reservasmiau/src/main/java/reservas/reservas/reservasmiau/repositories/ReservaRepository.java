package reservas.reservas.reservasmiau.repositories;

import org.springframework.data.repository.CrudRepository;

import reservas.reservas.reservasmiau.entities.Reserva;

import java.util.List;

public interface ReservaRepository extends CrudRepository<Reserva, Long> {

    List<Reserva> findByIdCancha(Long idCancha);
}

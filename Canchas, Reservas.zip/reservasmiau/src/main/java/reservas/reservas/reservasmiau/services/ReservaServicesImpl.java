package reservas.reservas.reservasmiau.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import reservas.reservas.reservasmiau.entities.Reserva;
import reservas.reservas.reservasmiau.repositories.ReservaRepository;

@Service
public class ReservaServicesImpl implements ReservaServices {

    @Autowired
    private ReservaRepository reservaRepository;

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String CANCHAS_URL = "http://localhost:8081/canchas/";

    @Override
    public Reserva crearReserva(Reserva reserva) {
        try {
            Object cancha = restTemplate.getForObject(CANCHAS_URL + reserva.getIdCancha(), Object.class);
            if (cancha == null) {
                return null;
            }
        } catch (RestClientException e) {
            return null;
        }
        return reservaRepository.save(reserva);
    }

    @Override
    public Reserva obtenerIdReserva(Long id) {
        return reservaRepository.findById(id).orElse(null);
    }

    @Override
    public List<Reserva> listaReservas() {
        return (List<Reserva>) reservaRepository.findAll();
    }

    @Override
    public List<Reserva> listaReservasPorCancha(Long idCancha) {
        return reservaRepository.findByIdCancha(idCancha);
    }
}
